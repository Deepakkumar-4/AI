from __future__ import annotations
import math
import random
import heapq
from collections import deque
from typing import Dict, List, Tuple, Optional, Any
import numpy as np

# Deterministic seed configuration
random.seed(2026)
np.random.seed(2026)

# ==============================================================================
# SECTION 1: GRAPH & HEURISTIC BENCHMARKS
# ==============================================================================

# Directed weighted graph setup[cite: 2]
GRAPH: Dict[str, Dict[str, int]] = {
    'S': {'A': 2, 'B': 4, 'C': 3},
    'A': {'D': 4, 'E': 7},
    'B': {'E': 1, 'F': 5},
    'C': {'F': 2},
    'D': {'G': 5},
    'E': {'G': 3},
    'F': {'G': 2},
    'G': {}
}

# H1: Admissible and Consistent[cite: 2, 3]
H1: Dict[str, int] = {
    'S': 7,
    'A': 7,
    'B': 4,
    'C': 4,
    'D': 5,
    'E': 3,
    'F': 2,
    'G': 0
}

# H_INCONSISTENT: Admissible but Inconsistent (h(A)=7 > c(A,D) + h(D) = 4 + 1 = 5)
H_INCONSISTENT: Dict[str, int] = {
    'S': 6,
    'A': 7,
    'B': 4,
    'C': 4,
    'D': 1,
    'E': 3,
    'F': 2,
    'G': 0
}

# H_GOAL: Zero heuristic at goal for backward search
H_BACKWARD: Dict[str, int] = {
    'S': 0,
    'A': 2,
    'B': 4,
    'C': 3,
    'D': 6,
    'E': 5,
    'F': 5,
    'G': 7
}


# ==============================================================================
# SECTION 2: A* SEARCH VARIATIONS (FROM SCRATCH)
# ==============================================================================

# Variation 1: Re-opening Closed Nodes (Inconsistent Heuristic Handling)[cite: 3]
def a_star_reopening(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str):
    """
    Graph-search A* that re-opens closed nodes when a strictly cheaper g-cost is discovered[cite: 3].
    Ensures optimal path retrieval even under admissible but inconsistent heuristics[cite: 3].
    """
    pq = [(h[start], start, 0, [start])]
    best_g = {start: 0}
    closed = set()
    expansion_order = []

    while pq:
        f, u, g, path = heapq.heappop(pq)

        # Ignore stale entries where a better path was already recorded[cite: 2]
        if g > best_g.get(u, math.inf):
            continue

        # Goal test when popped from queue[cite: 2]
        if u == goal:
            expansion_order.append(u)
            return path, g, expansion_order

        if u in closed:
            continue
        closed.add(u)
        expansion_order.append(u)

        for neighbor in sorted(graph[u].keys()):
            new_g = g + graph[u][neighbor]
            if new_g < best_g.get(neighbor, math.inf):
                best_g[neighbor] = new_g
                new_f = new_g + h[neighbor]
                # Reopen node if it was previously closed[cite: 3]
                if neighbor in closed:
                    closed.remove(neighbor)
                heapq.heappush(pq, (new_f, neighbor, new_g, path + [neighbor]))

    return None, -1, expansion_order
 

# Variation 2: Weighted A* (Epsilon-Admissible Search)
def weighted_a_star(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str, weight: float = 1.5):
    """
    Evaluates states by f(n) = g(n) + weight * h(n).
    Reduces total expansions at the cost of a bounded suboptimal cost (cost <= weight * optimal_cost).
    """
    pq = [(weight * h[start], start, 0, [start])]
    best_g = {start: 0}
    closed = set()
    expansion_order = []

    while pq:
        f, u, g, path = heapq.heappop(pq)

        if g > best_g.get(u, math.inf):
            continue

        if u == goal:
            expansion_order.append(u)
            return path, g, expansion_order

        if u in closed:
            continue
        closed.add(u)
        expansion_order.append(u)

        for neighbor in sorted(graph[u].keys()):
            new_g = g + graph[u][neighbor]
            if new_g < best_g.get(neighbor, math.inf):
                best_g[neighbor] = new_g
                new_f = new_g + (weight * h[neighbor])
                heapq.heappush(pq, (new_f, neighbor, new_g, path + [neighbor]))

    return None, -1, expansion_order


# Variation 3: Bidirectional A*
def bidirectional_a_star(graph: Dict[str, Dict[str, int]], h_f: Dict[str, int], h_b: Dict[str, int], start: str, goal: str):
    """
    Simultaneous forward search from start and backward search from goal on reversed edges.
    """
    rev_graph: Dict[str, Dict[str, int]] = {u: {} for u in graph}
    for u in graph:
        for v, cost in graph[u].items():
            rev_graph[v][u] = cost

    f_pq = [(h_f[start], start, 0, [start])]
    b_pq = [(h_b[goal], goal, 0, [goal])]

    f_best_g = {start: 0}
    b_best_g = {goal: 0}

    f_paths = {start: [start]}
    b_paths = {goal: [goal]}

    best_cost = math.inf
    meeting_node = None

    while f_pq and b_pq:
        # Forward Step
        _, u_f, g_f, path_f = heapq.heappop(f_pq)
        if g_f <= f_best_g.get(u_f, math.inf):
            if u_f in b_best_g:
                total = g_f + b_best_g[u_f]
                if total < best_cost:
                    best_cost = total
                    meeting_node = u_f

            for neighbor in sorted(graph[u_f].keys()):
                ng = g_f + graph[u_f][neighbor]
                if ng < f_best_g.get(neighbor, math.inf):
                    f_best_g[neighbor] = ng
                    f_paths[neighbor] = path_f + [neighbor]
                    heapq.heappush(f_pq, (ng + h_f[neighbor], neighbor, ng, f_paths[neighbor]))

        # Backward Step
        _, u_b, g_b, path_b = heapq.heappop(b_pq)
        if g_b <= b_best_g.get(u_b, math.inf):
            if u_b in f_best_g:
                total = g_b + f_best_g[u_b]
                if total < best_cost:
                    best_cost = total
                    meeting_node = u_b

            for prev in sorted(rev_graph[u_b].keys()):
                ng = g_b + rev_graph[u_b][prev]
                if ng < b_best_g.get(prev, math.inf):
                    b_best_g[prev] = ng
                    b_paths[prev] = [prev] + path_b
                    heapq.heappush(b_pq, (ng + h_b[prev], prev, ng, b_paths[prev]))

        # Termination criterion
        if meeting_node and (f_pq[0][0] + b_pq[0][0] >= best_cost):
            full_path = f_paths[meeting_node][:-1] + b_paths[meeting_node]
            return full_path, best_cost

    return None, -1


# ==============================================================================
# SECTION 3: LOCAL BEAM SEARCH VARIATIONS (FROM SCRATCH)
# ==============================================================================

# Variation 1: Stochastic Local Beam Search on Graph
def stochastic_beam_search(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str, beam_width: int = 2, max_steps: int = 50):
    """
    Selects k candidates probabilistically based on inverse heuristic weight (1 / (1 + h)).
    """
    current_beam = [(start, [start], 0)]
    kept_levels = []

    for _ in range(max_steps):
        candidates = {}
        for u, path, g in current_beam:
            for neighbor in graph[u].keys():
                new_g = g + graph[u][neighbor]
                new_path = path + [neighbor]
                if neighbor not in candidates or new_g < candidates[neighbor][0]:
                    candidates[neighbor] = (new_g, new_path)

        if not candidates:
            return None, -1, kept_levels

        cand_list = list(candidates.items())

        # Check goal arrival
        for node, (c, p) in cand_list:
            if node == goal:
                kept_levels.append([node])
                return p, c, kept_levels

        weights = [1.0 / (1.0 + h[node]) for node, _ in cand_list]
        total_w = sum(weights)
        probs = [w / total_w for w in weights]

        k = min(beam_width, len(cand_list))
        selected_idx = np.random.choice(len(cand_list), size=k, replace=False, p=probs)

        next_beam = [cand_list[i] for i in selected_idx]
        kept_levels.append([node for node, _ in next_beam])
        current_beam = [(node, path, cost) for node, (cost, path) in next_beam]

    return None, -1, kept_levels


# Variation 2: Local Beam Search directly on State Space Optimization (8-Queens)[cite: 2]
def queen_conflicts(state: List[int]) -> int:
    """Computes total attacking queen pairs (row and diagonal collisions)[cite: 2, 3]."""
    conflicts = 0
    n = len(state)
    for i in range(n):
        for j in range(i + 1, n):
            if state[i] == state[j] or abs(state[i] - state[j]) == (j - i):
                conflicts += 1
    return conflicts


def beam_search_8queens(k: int = 5, max_steps: int = 200):
    """
    Maintains a pool of k state configurations simultaneously[cite: 2].
    Generates all single-queen perturbations, sorts them globally, and keeps the top k[cite: 2, 3].
    """
    beam = [[random.randrange(8) for _ in range(8)] for _ in range(k)]

    for step in range(max_steps):
        for state in beam:
            if queen_conflicts(state) == 0:
                return state, 0, step

        successors = []
        for state in beam:
            for col in range(8):
                for row in range(8):
                    if row != state[col]:
                        neighbor = list(state)
                        neighbor[col] = row
                        successors.append(neighbor)

        # Retain top k successors across all generated branches[cite: 2, 3]
        successors.sort(key=queen_conflicts)
        beam = successors[:k]

    best_state = min(beam, key=queen_conflicts)
    return best_state, queen_conflicts(best_state), max_steps


# ==============================================================================
# SECTION 4: SIMULATED ANNEALING VARIATIONS (FROM SCRATCH)
# ==============================================================================

def accept_worse(delta: float, T: float) -> float:
    """Acceptance probability function for uphill/worse moves[cite: 2, 3]."""
    if delta <= 0:
        return 1.0
    if T <= 0:
        return 0.0
    try:
        return math.exp(-delta / T)
    except OverflowError:
        return 0.0


# Variation 1: Linear & Logarithmic Cooling Schedules
def sa_cooling_schedules(schedule: str = "linear", max_steps: int = 5000, seed: int = 0, T0: float = 10.0):
    """
    Executes simulated annealing under linear, logarithmic, or geometric temperature decay schedules[cite: 2].
    """
    random.seed(seed)
    current_state = [random.randrange(8) for _ in range(8)]
    current_cost = queen_conflicts(current_state)
    best_state = list(current_state)
    best_cost = current_cost

    for t in range(max_steps):
        if best_cost == 0:
            break

        if schedule == "linear":
            T = max(0.0, T0 - (T0 / max_steps) * t)
        elif schedule == "logarithmic":
            T = T0 / math.log(2 + t)
        else:
            T = T0 * (0.995 ** t)  # Geometric[cite: 2, 3]

        if T <= 1e-9:
            break

        # Perturb single queen[cite: 2, 3]
        col = random.randrange(8)
        current_row = current_state[col]
        choices = [r for r in range(8) if r != current_row]
        neighbor = list(current_state)
        neighbor[col] = random.choice(choices)

        neighbor_cost = queen_conflicts(neighbor)
        delta = neighbor_cost - current_cost

        if delta <= 0 or random.random() < accept_worse(delta, T):
            current_state = neighbor
            current_cost = neighbor_cost
            if current_cost < best_cost:
                best_cost = current_cost
                best_state = list(current_state)

    return best_state, best_cost


# Variation 2: Permutation-Based SA (Column-Swapping Neighborhood)
def sa_permutation_8queens(max_steps: int = 5000, seed: int = 0, T0: float = 10.0, cooling: float = 0.995):
    """
    Formulates 8-Queens using a permutation of [0..7].
    Guarantees horizontal row attacks are always 0; moves are generated by swapping two columns.
    """
    random.seed(seed)
    current_state = list(range(8))
    random.shuffle(current_state)
    current_cost = queen_conflicts(current_state)
    best_state = list(current_state)
    best_cost = current_cost

    for t in range(max_steps):
        if best_cost == 0:
            break

        T = T0 * (cooling ** t)
        if T <= 1e-9:
            break

        # Swap mutation operator
        i, j = random.sample(range(8), 2)
        neighbor = list(current_state)
        neighbor[i], neighbor[j] = neighbor[j], neighbor[i]

        neighbor_cost = queen_conflicts(neighbor)
        delta = neighbor_cost - current_cost

        if delta <= 0 or random.random() < accept_worse(delta, T):
            current_state = neighbor
            current_cost = neighbor_cost
            if current_cost < best_cost:
                best_cost = current_cost
                best_state = list(current_state)

    return best_state, best_cost


# ==============================================================================
# SECTION 5: GENETIC ALGORITHM VARIATIONS (FROM SCRATCH)
# ==============================================================================

MAX_PAIRS = 28  # 8 * 7 // 2[cite: 2, 3]

def ga_fitness(chromosome: List[int]) -> int:
    return MAX_PAIRS - queen_conflicts(chromosome)


# Genetic Operators
def two_point_crossover(p1: List[int], p2: List[int]) -> Tuple[List[int], List[int]]:
    """Exchanges segment bounded between two interior cut points."""
    pt1 = random.randint(1, len(p1) - 2)
    pt2 = random.randint(pt1 + 1, len(p1) - 1)
    c1 = p1[:pt1] + p2[pt1:pt2] + p1[pt2:]
    c2 = p2[:pt1] + p1[pt1:pt2] + p2[pt2:]
    return c1, c2


def uniform_crossover(p1: List[int], p2: List[int], swap_prob: float = 0.5) -> Tuple[List[int], List[int]]:
    """Mixes genes from both parents based on an independent coin flip per index."""
    c1, c2 = list(p1), list(p2)
    for i in range(len(p1)):
        if random.random() < swap_prob:
            c1[i], c2[i] = p2[i], p1[i]
    return c1, c2


def roulette_wheel_select(population: List[List[int]]) -> List[int]:
    """Fitness-proportionate parent selection."""
    fits = [ga_fitness(ind) for ind in population]
    total_fit = sum(fits)
    if total_fit == 0:
        return list(random.choice(population))

    pick = random.uniform(0, total_fit)
    running_sum = 0
    for ind, fit in zip(population, fits):
        running_sum += fit
        if running_sum >= pick:
            return list(ind)
    return list(population[-1])


def ga_mutate(chromosome: List[int], mutation_rate: float = 0.10) -> List[int]:
    mutated = list(chromosome)
    for i in range(len(mutated)):
        if random.random() < mutation_rate:
            choices = [r for r in range(8) if r != mutated[i]]
            mutated[i] = random.choice(choices)
    return mutated


# Complete GA with K-Elitism & Configurable Operators
def genetic_algorithm_advanced(
    pop_size: int = 100,
    generations: int = 500,
    mutation_rate: float = 0.10,
    crossover_type: str = "two_point",
    selection_type: str = "roulette",
    elite_count: int = 4,
    seed: int = 0
):
    """
    GA utilizing Multi-Elitism, Roulette/Tournament Selection, and One/Two-Point Crossover[cite: 2, 3].
    """
    random.seed(seed)
    population = [[random.randrange(8) for _ in range(8)] for _ in range(pop_size)]

    for g in range(1, generations + 1):
        population.sort(key=ga_fitness, reverse=True)
        if ga_fitness(population[0]) == MAX_PAIRS:
            return population[0], MAX_PAIRS, g

        new_population = []

        # Multi-individual elitism preservation
        for i in range(elite_count):
            new_population.append(list(population[i]))

        while len(new_population) < pop_size:
            # Selection
            if selection_type == "roulette":
                p1 = roulette_wheel_select(population)
                p2 = roulette_wheel_select(population)
            else:
                p1 = max(random.sample(population, 3), key=ga_fitness)
                p2 = max(random.sample(population, 3), key=ga_fitness)

            # Crossover
            if crossover_type == "two_point":
                c1, c2 = two_point_crossover(p1, p2)
            elif crossover_type == "uniform":
                c1, c2 = uniform_crossover(p1, p2)
            else:
                pt = random.randint(1, 7)
                c1, c2 = p1[:pt] + p2[pt:], p2[:pt] + p1[pt:]  # One-point[cite: 2, 3]

            new_population.append(ga_mutate(c1, mutation_rate))
            if len(new_population) < pop_size:
                new_population.append(ga_mutate(c2, mutation_rate))

        population = new_population

    population.sort(key=ga_fitness, reverse=True)
    return population[0], ga_fitness(population[0]), generations


# ==============================================================================
# SECTION 6: EXECUTION & TEST VERIFICATION
# ==============================================================================

if __name__ == "__main__":
    print("-" * 60)
    print("1. A* VARIATIONS VERIFICATION")
    print("-" * 60)
    path_reopen, cost_reopen, exp_reopen = a_star_reopening(GRAPH, H_INCONSISTENT, 'S', 'G')
    print(f"A* Reopening: Path={path_reopen}, Cost={cost_reopen}, Expansions={exp_reopen}")

    path_weighted, cost_weighted, _ = weighted_a_star(GRAPH, H1, 'S', 'G', weight=2.0)
    print(f"Weighted A* (w=2.0): Path={path_weighted}, Cost={cost_weighted}")

    path_bi, cost_bi = bidirectional_a_star(GRAPH, H1, H_BACKWARD, 'S', 'G')
    print(f"Bidirectional A*: Path={path_bi}, Cost={cost_bi}")

    print("\n" + "-" * 60)
    print("2. LOCAL BEAM SEARCH VARIATIONS")
    print("-" * 60)
    stoch_path, stoch_cost, stoch_levels = stochastic_beam_search(GRAPH, H1, 'S', 'G', beam_width=2)
    print(f"Stochastic Beam (Graph): Path={stoch_path}, Cost={stoch_cost}")

    opt_state, opt_conflicts, opt_steps = beam_search_8queens(k=10, max_steps=100)
    print(f"Local Beam (8-Queens): Conflicts={opt_conflicts}, Found in steps={opt_steps}")

    print("\n" + "-" * 60)
    print("3. SIMULATED ANNEALING VARIATIONS")
    print("-" * 60)
    sa_lin_state, sa_lin_cost = sa_cooling_schedules(schedule="linear", seed=42)
    print(f"SA (Linear Cooling): Best Conflicts={sa_lin_cost}")

    sa_perm_state, sa_perm_cost = sa_permutation_8queens(seed=42)
    print(f"SA (Permutation Swap): Best Conflicts={sa_perm_cost}")

    print("\n" + "-" * 60)
    print("4. GENETIC ALGORITHM VARIATIONS")
    print("-" * 60)
    ga_adv_state, ga_adv_fit, ga_adv_gens = genetic_algorithm_advanced(
        crossover_type="two_point",
        selection_type="roulette",
        elite_count=4,
        seed=42
    )
    print(f"GA (Roulette + Two-Point + Elitism=4): Fitness={ga_adv_fit}/{MAX_PAIRS}, Gens={ga_adv_gens}")