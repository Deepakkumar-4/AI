# ==============================================================================
# AI512: Artificial Intelligence — Lab 3: Full Reference Implementation
# ==============================================================================

from __future__ import annotations
import math
import random
import heapq
from collections import deque
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
import matplotlib.pyplot as plt

# Set random seeds for deterministic reproducibility
random.seed(2026)
np.random.seed(2026)


# ==============================================================================
# 1. GRAPH AND HEURISTIC DATASETS
# ==============================================================================

GRAPH = {
    'S': {'A': 2, 'B': 4, 'C': 3},
    'A': {'D': 4, 'E': 7},
    'B': {'E': 1, 'F': 5},
    'C': {'F': 2},
    'D': {'G': 5},
    'E': {'G': 3},
    'F': {'G': 2},
    'G': {}
}

# H1 is admissible and consistent
H1 = {
    'S': 7,
    'A': 7,
    'B': 4,
    'C': 4,
    'D': 5,
    'E': 3,
    'F': 2,
    'G': 0
}

# H2 contains an overestimation violation at C
H2 = {
    'S': 7,
    'A': 9,
    'B': 4,
    'C': 5,
    'D': 5,
    'E': 3,
    'F': 2,
    'G': 0
}

# H_IDA is deliberately less informed for visible IDA* threshold iterations
H_IDA = {
    'S': 4,
    'A': 5,
    'B': 3,
    'C': 2,
    'D': 4,
    'E': 2,
    'F': 1,
    'G': 0
}


# ==============================================================================
# 2. PART 1 — HEURISTIC DIAGNOSTICS (ADMISSIBILITY & CONSISTENCY)
# ==============================================================================

def compute_true_costs(graph: Dict[str, Dict[str, int]], goal: str) -> Dict[str, float]:
    """
    Compute true minimum remaining cost h*(n) from every node to goal
    using Dijkstra on the reversed graph.
    """
    rev_graph = {node: {} for node in graph}
    for u, neighbors in graph.items():
        for v, cost in neighbors.items():
            rev_graph[v][u] = cost

    dist = {node: math.inf for node in graph}
    dist[goal] = 0
    pq = [(0, goal)]

    while pq:
        d, u = heapq.heappop(pq)
        if d > dist[u]:
            continue
        for prev_node, cost in rev_graph[u].items():
            if dist[u] + cost < dist[prev_node]:
                dist[prev_node] = dist[u] + cost
                heapq.heappush(pq, (dist[prev_node], prev_node))
    return dist


def check_admissibility(graph: Dict[str, Dict[str, int]], heuristic: Dict[str, int], goal: str):
    """Checks admissibility: h(n) <= h*(n)."""
    true_costs = compute_true_costs(graph, goal)
    violations = []
    admissible = True

    for node, h_val in heuristic.items():
        h_star = true_costs[node]
        if h_val > h_star:
            admissible = False
            violations.append(f"Node {node}: h({node})={h_val} > h*({node})={h_star}")

    return admissible, violations, true_costs


def check_consistency(graph: Dict[str, Dict[str, int]], heuristic: Dict[str, int]):
    """Checks consistency: h(u) <= c(u, v) + h(v)."""
    violations = []
    consistent = True

    for u, neighbors in graph.items():
        for v, cost in neighbors.items():
            if heuristic[u] > cost + heuristic[v]:
                consistent = False
                violations.append(
                    f"Edge {u}->{v}: h({u})={heuristic[u]} > c({u},{v})={cost} + h({v})={heuristic[v]} (sum={cost + heuristic[v]})"
                )

    return consistent, violations


def classify_heuristic(graph: Dict[str, Dict[str, int]], heuristic: Dict[str, int], goal: str) -> str:
    admissible, _, _ = check_admissibility(graph, heuristic, goal)
    consistent, _ = check_consistency(graph, heuristic)

    if admissible and consistent:
        return "Both admissible and consistent"
    elif admissible and not consistent:
        return "Admissible but not consistent"
    elif not admissible and consistent:
        return "Consistent but not admissible"
    else:
        return "Neither admissible nor consistent"


# ==============================================================================
# 3. PART 2 — GREEDY BEST-FIRST SEARCH (GBFS)
# ==============================================================================

def path_cost(graph: Dict[str, Dict[str, int]], path: Optional[List[str]]) -> int:
    if not path:
        return -1
    return sum(graph[u][v] for u, v in zip(path, path[1:]))


def greedy_best_first_search(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str):
    """Returns (path, cost, expansion_order)."""
    pq = [(h[start], start, [start])]
    visited = set()
    expansion_order = []

    while pq:
        h_val, u, path = heapq.heappop(pq)

        if u in visited:
            continue
        visited.add(u)
        expansion_order.append(u)

        if u == goal:
            return path, path_cost(graph, path), expansion_order

        for neighbor in sorted(graph[u].keys()):
            if neighbor not in visited:
                heapq.heappush(pq, (h[neighbor], neighbor, path + [neighbor]))

    return None, -1, expansion_order


# ==============================================================================
# 4. PART 3 — A* SEARCH
# ==============================================================================

def a_star_search(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str):
    """Returns (path, cost, expansion_order)."""
    pq = [(h[start], start, 0, [start])]
    best_g = {start: 0}
    closed = set()
    expansion_order = []

    while pq:
        f, u, g, path = heapq.heappop(pq)

        if g > best_g.get(u, math.inf):
            continue

        if u == goal:
            expansion_order.append(u)
            return path, g, expansion_order

        if u in closed:
            continue
        closed.add(u)
        expansion_order.append(u)

        for neighbor in sorted(graph[u].keys()):
            new_g = g + graph[u][neighbor]
            if new_g < best_g.get(neighbor, math.inf):
                best_g[neighbor] = new_g
                new_f = new_g + h[neighbor]
                heapq.heappush(pq, (new_f, neighbor, new_g, path + [neighbor]))

    return None, -1, expansion_order


# ==============================================================================
# 5. PART 4 — IDA* (ITERATIVE DEEPENING A*)
# ==============================================================================

def ida_star(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str):
    """Returns (path, cost, thresholds, total_expansions)."""
    threshold = h[start]
    thresholds = [threshold]
    total_expansions = 0

    def search(path, g, bound):
        nonlocal total_expansions
        u = path[-1]
        f = g + h[u]

        if f > bound:
            return f, None

        total_expansions += 1

        if u == goal:
            return "FOUND", path

        min_exceeded = math.inf
        for neighbor in sorted(graph[u].keys()):
            if neighbor not in path:
                cost = graph[u][neighbor]
                res, found_path = search(path + [neighbor], g + cost, bound)
                if res == "FOUND":
                    return "FOUND", found_path
                if res < min_exceeded:
                    min_exceeded = res

        return min_exceeded, None

    while True:
        res, path = search([start], 0, threshold)
        if res == "FOUND":
            return path, path_cost(graph, path), thresholds, total_expansions
        if res == math.inf:
            return None, -1, thresholds, total_expansions
        threshold = res
        thresholds.append(threshold)


# ==============================================================================
# 6. PART 5 — BEAM SEARCH
# ==============================================================================

def beam_search(graph: Dict[str, Dict[str, int]], h: Dict[str, int], start: str, goal: str, beam_width: int = 2):
    """Returns (path, cost, kept_levels)."""
    if beam_width <= 0:
        raise ValueError("beam_width must be positive")

    current_beam = [(start, [start], 0)]
    kept_levels = []

    if start == goal:
        return [start], 0, [[start]]

    while current_beam:
        candidates = {}

        for u, path, g in current_beam:
            for neighbor in graph[u].keys():
                cost = graph[u][neighbor]
                new_g = g + cost
                new_path = path + [neighbor]

                if neighbor not in candidates or new_g < candidates[neighbor][0]:
                    candidates[neighbor] = (new_g, new_path)

        if not candidates:
            return None, -1, kept_levels

        sorted_candidates = sorted(
            candidates.items(), key=lambda item: (h[item[0]], item[0])
        )

        next_beam_candidates = sorted_candidates[:beam_width]
        kept_nodes = [node for node, _ in next_beam_candidates]
        kept_levels.append(kept_nodes)

        for node, (c, p) in next_beam_candidates:
            if node == goal:
                return p, c, kept_levels

        current_beam = [
            (node, path, cost) for node, (cost, path) in next_beam_candidates
        ]

    return None, -1, kept_levels


# ==============================================================================
# 7. PART 6 — COMPARISON BENCHMARK
# ==============================================================================

def build_search_comparison(graph, h_gbfs_astar, h_ida, start="S", goal="G", beam_width=2):
    _, gbfs_c, gbfs_exp = greedy_best_first_search(graph, h_gbfs_astar, start, goal)
    _, astar_c, astar_exp = a_star_search(graph, h_gbfs_astar, start, goal)
    _, ida_c, _, ida_exp = ida_star(graph, h_ida, start, goal)
    _, beam_c, beam_levels = beam_search(graph, h_gbfs_astar, start, goal, beam_width=beam_width)

    beam_exp = 1
    for lvl in beam_levels:
        if goal in lvl:
            break
        beam_exp += len(lvl)

    return {
        "Greedy Best-First": {
            "cost": gbfs_c,
            "expansions": len(gbfs_exp),
            "optimal?": "No (heuristic-driven)",
            "memory_comment": "stores large frontier",
        },
        "A*": {
            "cost": astar_c,
            "expansions": len(astar_exp),
            "optimal?": "Yes (admissible/consistent)",
            "memory_comment": "stores large frontier",
        },
        "IDA*": {
            "cost": ida_c,
            "expansions": ida_exp,
            "optimal?": "Yes (optimal path found)",
            "memory_comment": "linear in depth",
        },
        "Beam Search k=2": {
            "cost": beam_c,
            "expansions": beam_exp,
            "optimal?": "No (incomplete/suboptimal)",
            "memory_comment": "bounded by k per level",
        },
    }


# ==============================================================================
# 8. PART 7 & 8 — GAME TREE: MINIMAX & ALPHA-BETA PRUNING
# ==============================================================================

GAME_TREE = {
    'R': ['A', 'B', 'C'],
    'A': ['A1', 'A2'],
    'B': ['B1', 'B2'],
    'C': ['C1', 'C2'],
    'A1': ['A1a', 'A1b'], 'A2': ['A2a', 'A2b'],
    'B1': ['B1a', 'B1b'], 'B2': ['B2a', 'B2b'],
    'C1': ['C1a', 'C1b'], 'C2': ['C2a', 'C2b'],
}

UTILITY = {
    'A1a': 3, 'A1b': 5,
    'A2a': 6, 'A2b': 9,
    'B1a': 1, 'B1b': 2,
    'B2a': 0, 'B2b': -1,
    'C1a': 7, 'C1b': 4,
    'C2a': 5, 'C2b': 6,
}

def minimax(node, maximizing_player=True):
    if node in UTILITY:
        return UTILITY[node]

    children = GAME_TREE.get(node, [])
    if maximizing_player:
        max_val = -math.inf
        for child in children:
            max_val = max(max_val, minimax(child, maximizing_player=False))
        return max_val
    else:
        min_val = math.inf
        for child in children:
            min_val = min(min_val, minimax(child, maximizing_player=True))
        return min_val

def minimax_decision(root="R"):
    best_val = -math.inf
    best_move = None
    for child in GAME_TREE[root]:
        val = minimax(child, maximizing_player=False)
        if val > best_val:
            best_val = val
            best_move = child
    return best_move, best_val

def alpha_beta(node, alpha=-math.inf, beta=math.inf, maximizing_player=True, stats=None):
    if stats is None:
        stats = {"leaves": 0, "prunes": 0}

    if node in UTILITY:
        stats["leaves"] += 1
        return UTILITY[node]

    children = GAME_TREE.get(node, [])

    if maximizing_player:
        v = -math.inf
        for child in children:
            v = max(v, alpha_beta(child, alpha, beta, False, stats))
            alpha = max(alpha, v)
            if alpha >= beta:
                stats["prunes"] += 1
                break
        return v
    else:
        v = math.inf
        for child in children:
            v = min(v, alpha_beta(child, alpha, beta, True, stats))
            beta = min(beta, v)
            if alpha >= beta:
                stats["prunes"] += 1
                break
        return v

def alpha_beta_decision(root="R"):
    stats = {"leaves": 0, "prunes": 0}
    alpha = -math.inf
    beta = math.inf
    best_val = -math.inf
    best_move = None

    for child in GAME_TREE[root]:
        val = alpha_beta(child, alpha, beta, False, stats)
        if val > best_val:
            best_val = val
            best_move = child
        alpha = max(alpha, best_val)

    return best_move, best_val, stats


# ==============================================================================
# 9. PART 9 — SIMULATED ANNEALING (8-QUEENS)
# ==============================================================================

N = 8

def queen_conflicts(state: List[int]) -> int:
    conflicts = 0
    n = len(state)
    for i in range(n):
        for j in range(i + 1, n):
            if state[i] == state[j] or abs(state[i] - state[j]) == (j - i):
                conflicts += 1
    return conflicts

def random_neighbor(state: List[int]) -> List[int]:
    col = random.randrange(len(state))
    current_row = state[col]
    choices = [r for r in range(len(state)) if r != current_row]
    new_state = list(state)
    new_state[col] = random.choice(choices)
    return new_state

def temperature_schedule(t: int, T0: float = 10.0, cooling: float = 0.995) -> float:
    return T0 * (cooling ** t)

def accept_worse(delta: float, T: float) -> float:
    if delta <= 0:
        return 1.0
    if T <= 0:
        return 0.0
    try:
        return math.exp(-delta / T)
    except OverflowError:
        return 0.0

def simulated_annealing(max_steps: int = 5000, seed: int = 0, T0: float = 10.0, cooling: float = 0.995):
    random.seed(seed)
    current_state = [random.randrange(N) for _ in range(N)]
    current_cost = queen_conflicts(current_state)

    best_state = list(current_state)
    best_cost = current_cost
    history = [best_cost]

    for t in range(max_steps):
        if best_cost == 0:
            break

        T = temperature_schedule(t, T0, cooling)
        if T <= 1e-9:
            break

        neighbor = random_neighbor(current_state)
        neighbor_cost = queen_conflicts(neighbor)
        delta = neighbor_cost - current_cost

        if delta <= 0 or random.random() < accept_worse(delta, T):
            current_state = neighbor
            current_cost = neighbor_cost
            if current_cost < best_cost:
                best_cost = current_cost
                best_state = list(current_state)

        history.append(best_cost)

    return best_state, best_cost, history


# ==============================================================================
# 10. PART 10 — GENETIC ALGORITHM (8-QUEENS)
# ==============================================================================

MAX_PAIRS = N * (N - 1) // 2

def fitness(chromosome: List[int]) -> int:
    return MAX_PAIRS - queen_conflicts(chromosome)

def random_chromosome() -> List[int]:
    return [random.randrange(N) for _ in range(N)]

def tournament_select(population: List[List[int]], tournament_size: int = 3) -> List[int]:
    sample = random.sample(population, tournament_size)
    best = max(sample, key=fitness)
    return list(best)

def one_point_crossover(p1: List[int], p2: List[int]) -> Tuple[List[int], List[int]]:
    point = random.randint(1, len(p1) - 1)
    c1 = p1[:point] + p2[point:]
    c2 = p2[:point] + p1[point:]
    return c1, c2

def mutate(chromosome: List[int], mutation_rate: float = 0.10) -> List[int]:
    mutated = list(chromosome)
    for i in range(len(mutated)):
        if random.random() < mutation_rate:
            choices = [r for r in range(N) if r != mutated[i]]
            mutated[i] = random.choice(choices)
    return mutated

def genetic_algorithm(pop_size: int = 100, generations: int = 500, mutation_rate: float = 0.10, seed: int = 0):
    random.seed(seed)
    population = [random_chromosome() for _ in range(pop_size)]

    current_best = max(population, key=fitness)
    best_fit = fitness(current_best)
    best_history = [best_fit]

    if best_fit == MAX_PAIRS:
        return current_best, best_fit, best_history, 0

    gen_used = 0
    for g in range(1, generations + 1):
        gen_used = g
        new_population = []

        # 1-individual elitism
        elite = list(max(population, key=fitness))
        new_population.append(elite)

        while len(new_population) < pop_size:
            p1 = tournament_select(population)
            p2 = tournament_select(population)
            c1, c2 = one_point_crossover(p1, p2)
            new_population.append(mutate(c1, mutation_rate))
            if len(new_population) < pop_size:
                new_population.append(mutate(c2, mutation_rate))

        population = new_population
        current_best = max(population, key=fitness)
        cur_fit = fitness(current_best)

        if cur_fit > best_fit:
            best_fit = cur_fit

        best_history.append(best_fit)

        if best_fit == MAX_PAIRS:
            break

    return current_best, best_fit, best_history, gen_used


# ==============================================================================
# 11. PART 11 — EXPERIMENTAL EVALUATION (SA VS GA)
# ==============================================================================

def run_sa_ga_experiment(num_seeds: int = 50):
    sa_final_conflicts = []
    ga_final_conflicts = []
    sa_iterations = []
    ga_generations_used = []

    for seed in range(num_seeds):
        _, sa_cost, sa_hist = simulated_annealing(seed=seed)
        sa_final_conflicts.append(sa_cost)
        sa_iterations.append(len(sa_hist) - 1)

        _, ga_fit, _, ga_gen = genetic_algorithm(seed=seed)
        ga_final_conflicts.append(MAX_PAIRS - ga_fit)
        ga_generations_used.append(ga_gen)

    return (
        sa_final_conflicts,
        ga_final_conflicts,
        sa_iterations,
        ga_generations_used,
    )

def summarize_trials(name: str, conflicts: List[int], effort: List[int], effort_label: str):
    conflicts_arr = np.array(conflicts)
    effort_arr = np.array(effort)
    success_rate = 100.0 * np.mean(conflicts_arr == 0)

    print(f"\n--- {name} Results ({len(conflicts)} trials) ---")
    print(f"Success Rate          : {success_rate:.1f}%")
    print(f"Mean Conflicts        : {np.mean(conflicts_arr):.2f}")
    print(f"Median Conflicts      : {np.median(conflicts_arr):.1f}")
    print(f"Best / Worst Conflicts: {np.min(conflicts_arr)} / {np.max(conflicts_arr)}")
    print(f"Average {effort_label}: {np.mean(effort_arr):.2f}")

def plot_conflict_distribution(sa_final_conflicts: List[int], ga_final_conflicts: List[int]):
    plt.figure(figsize=(8, 4))
    bins = np.arange(-0.5, max(max(sa_final_conflicts), max(ga_final_conflicts)) + 1.5, 1)

    plt.hist(
        sa_final_conflicts,
        bins=bins,
        alpha=0.6,
        label="Simulated Annealing",
        edgecolor="black",
    )
    plt.hist(
        ga_final_conflicts,
        bins=bins,
        alpha=0.6,
        label="Genetic Algorithm",
        edgecolor="black",
    )

    plt.title("Final Conflict Distribution (50 Seeds)")
    plt.xlabel("Conflicts (0 = Solution)")
    plt.ylabel("Frequency")
    plt.xticks(range(int(bins[-1]) + 1))
    plt.legend()
    plt.grid(axis="y", linestyle="--", alpha=0.7)
    plt.tight_layout()
    plt.show()


# ==============================================================================
# EXECUTION DEMO / VALIDATION BLOCK
# ==============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("RUNNING HEURISTIC DIAGNOSIS")
    print("=" * 50)
    for name, heuristic in [('H1', H1), ('H2', H2)]:
        print(f"\nChecking {name}:")
        adm, adm_v, true_c = check_admissibility(GRAPH, heuristic, 'G')
        con, con_v = check_consistency(GRAPH, heuristic)
        print("True remaining costs:", true_c)
        print("Admissible:", adm)
        if adm_v:
            print("Admissibility violations:", adm_v)
        print("Consistent:", con)
        if con_v:
            print("Consistency violations:", con_v)
        print("Classification:", classify_heuristic(GRAPH, heuristic, 'G'))

    print("\n" + "=" * 50)
    print("RUNNING SEARCH ALGORITHMS (GRAPH + H1)")
    print("=" * 50)
    # GBFS
    gp, gc, ge = greedy_best_first_search(GRAPH, H1, 'S', 'G')
    print(f"GBFS: path={gp}, cost={gc}, expansions={ge}")

    # A*
    ap, ac, ae = a_star_search(GRAPH, H1, 'S', 'G')
    print(f"A*  : path={ap}, cost={ac}, expansions={ae}")

    # IDA*
    ip, ic, it, ie = ida_star(GRAPH, H_IDA, 'S', 'G')
    print(f"IDA*: path={ip}, cost={ic}, thresholds={it}, expansions={ie}")

    # Beam Search
    for w in [1, 2, 3]:
        bp, bc, bl = beam_search(GRAPH, H1, 'S', 'G', beam_width=w)
        print(f"Beam (width={w}): path={bp}, cost={bc}, levels={bl}")

    print("\n" + "=" * 50)
    print("RUNNING SEARCH COMPARISON TABLE")
    print("=" * 50)
    comp = build_search_comparison(GRAPH, H1, H_IDA)
    print(f"{'Algorithm':<22} | {'Cost':<6} | {'Expansions':<10} | {'Optimality':<27} | Memory")
    print('-' * 105)
    for name, d in comp.items():
        print(f"{name:<22} | {str(d['cost']):<6} | {str(d['expansions']):<10} | {d['optimal?']:<27} | {d['memory_comment']}")

    print("\n" + "=" * 50)
    print("RUNNING ADVERSARIAL SEARCH")
    print("=" * 50)
    m_move, m_val = minimax_decision('R')
    print(f"Minimax: Best root move={m_move}, value={m_val}")

    ab_move, ab_val, ab_stats = alpha_beta_decision('R')
    print(f"Alpha-Beta: Best move={ab_move}, value={ab_val}, leaves={ab_stats['leaves']}, prunes={ab_stats['prunes']}")

    print("\n" + "=" * 50)
    print("RUNNING OPTIMIZATION (8-QUEENS)")
    print("=" * 50)
    sa_state, sa_cost, sa_hist = simulated_annealing(seed=7)
    print(f"Simulated Annealing (seed=7): State={sa_state}, Conflicts={sa_cost}")

    ga_state, ga_fit, ga_hist, ga_gen = genetic_algorithm(seed=7)
    print(f"Genetic Algorithm (seed=7)  : State={ga_state}, Conflicts={MAX_PAIRS - ga_fit}, Generations={ga_gen}")