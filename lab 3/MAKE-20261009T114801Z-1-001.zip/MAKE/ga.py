import random

# ---------------------------------------------------------
# 1. DEFINE YOUR CUSTOM FITNESS FUNCTION HERE
# ---------------------------------------------------------
def custom_fitness(chromosome):
    """
    Example: Maximize f(x) = sum of numbers in chromosome.
    Replace this with whatever mathematical equation or logic you want!
    """
    return sum(chromosome)


# ---------------------------------------------------------
# 2. SIMPLE GENETIC ALGORITHM
# ---------------------------------------------------------
def simple_genetic_algorithm(
    fitness_func,
    chrom_len=10,
    gene_choices=[0, 1],  # Allowed values for each gene
    pop_size=50,
    generations=100,
    mutation_rate=0.05
):
    # Initialize random population[cite: 2]
    population = [
        [random.choice(gene_choices) for _ in range(chrom_len)]
        for _ in range(pop_size)
    ]

    for gen in range(generations):
        # Sort population so fittest comes first[cite: 2, 3]
        population.sort(key=fitness_func, reverse=True)

        # 1-Individual Elitism (keep the best one)[cite: 2, 3]
        new_population = [list(population[0])]

        while len(new_population) < pop_size:
            # Tournament selection (pick best of 3 random candidates)[cite: 2, 3]
            p1 = max(random.sample(population, 3), key=fitness_func)
            p2 = max(random.sample(population, 3), key=fitness_func)

            # 1-Point Crossover[cite: 2, 3]
            pt = random.randint(1, chrom_len - 1)
            c1 = p1[:pt] + p2[pt:]
            c2 = p2[:pt] + p1[pt:]

            # Mutation: randomly flip a gene[cite: 2, 3]
            for child in [c1, c2]:
                for i in range(chrom_len):
                    if random.random() < mutation_rate:
                        child[i] = random.choice(gene_choices)
                
                if len(new_population) < pop_size:
                    new_population.append(child)

        population = new_population

    # Return overall best
    population.sort(key=fitness_func, reverse=True)
    best = population[0]
    return best, fitness_func(best)


# ---------------------------------------------------------
# 3. RUN IT
# ---------------------------------------------------------
if __name__ == "__main__":
    best_chromosome, best_score = simple_genetic_algorithm(
        fitness_func=custom_fitness,
        chrom_len=8,
        gene_choices=[0, 1, 2, 3, 4, 5],  # can be [0, 1] for binary
        generations=50
    )

    print("Best Chromosome :", best_chromosome)
    print("Maximized Output:", best_score)



#  -------------------   second implemenatation sample input ga -----------------
import random

# Custom fitness function
def custom_fitness(chromosome):
    return sum(chromosome)

# -------------------------------------------------------------------------
# Genetic Algorithm accepting user-provided initial sample / population
# -------------------------------------------------------------------------
def genetic_algorithm_custom_sample(
    fitness_func,
    initial_population,       # <--- Pass your own samples here
    gene_choices=[0, 1, 2, 3, 4, 5],
    generations=50,
    mutation_rate=0.05
):
    # Use the user's provided sample as the starting population
    population = [list(ind) for ind in initial_population]
    pop_size = len(population)
    chrom_len = len(population[0])

    for gen in range(generations):
        # Sort so fittest comes first
        population.sort(key=fitness_func, reverse=True)

        # Elitism: keep best chromosome
        new_population = [list(population[0])]

        while len(new_population) < pop_size:
            # Tournament selection: choose best from 3 random members of current pool
            p1 = max(random.sample(population, min(3, pop_size)), key=fitness_func)
            p2 = max(random.sample(population, min(3, pop_size)), key=fitness_func)

            # 1-Point Crossover
            pt = random.randint(1, chrom_len - 1)
            c1 = p1[:pt] + p2[pt:]
            c2 = p2[:pt] + p1[pt:]

            # Mutation
            for child in [c1, c2]:
                for i in range(chrom_len):
                    if random.random() < mutation_rate:
                        child[i] = random.choice(gene_choices)
                
                if len(new_population) < pop_size:
                    new_population.append(child)

        population = new_population

    population.sort(key=fitness_func, reverse=True)
    best = population[0]
    return best, fitness_func(best)


# -------------------------------------------------------------------------
# Usage: Define your exact starting samples
# -------------------------------------------------------------------------
if __name__ == "__main__":
    # Your custom starting samples (seeded population)
    my_custom_samples = [
        [1, 0, 2, 1, 0, 3],
        [4, 2, 1, 0, 1, 2],
        [0, 0, 5, 2, 1, 1],
        [3, 3, 2, 1, 0, 4],
        [1, 1, 1, 2, 2, 3],
    ]

    best_chrom, best_score = genetic_algorithm_custom_sample(
        fitness_func=custom_fitness,
        initial_population=my_custom_samples,
        gene_choices=[0, 1, 2, 3, 4, 5],
        generations=30
    )

    print("Initial Custom Samples:")
    for sample in my_custom_samples:
        print(" ", sample, "-> Fitness:", custom_fitness(sample))

    print("\nOptimized Best Chromosome:", best_chrom)
    print("Maximized Output        :", best_score)